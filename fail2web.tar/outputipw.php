<?php
$outputipw = $_POST['outputipw'];
echo shell_exec("sudo echo '$outputipw OK' >> /opt/zimbra/conf/postfix_rbl_override 2>&1");
echo shell_exec("sudo su - zimbra -c 'postmap /opt/zimbra/conf/postfix_rbl_override' 2>&1");
header('Location: http://mail.pentaservice.ga:8090/amavis.php');
exit;
?>