<?php
$outputipwr = $_POST['outputipwr'];
    $filename = '/opt/zimbra/conf/postfix_rbl_override';
    $lines = file($filename); // reads a file into a array with the lines
    $output = '';

    foreach ($lines as $line) {
        if (!strstr($line, $outputipwr)) {
            $output .= $line;
        } 
    }

    // replace the contents of the file with the output
    file_put_contents($filename, $output);
header('Location: http://mail.pentaservice.ga:8091/amavis.php');
exit;
?>