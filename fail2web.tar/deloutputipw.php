<?php
echo shell_exec("> /opt/zimbra/conf/postfix_rbl_override 2>&1");
header('Location: http://mail.pentaservice.ga:8090/amavis.php');
exit;
?>