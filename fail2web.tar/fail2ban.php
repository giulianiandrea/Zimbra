<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>Log Fail2ban Amavis - Console</title>
</head>
<body>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table>
<?php
$output = shell_exec('sudo sqlite3 /var/lib/fail2ban/fail2ban.sqlite3 "select ip,jail from bips" 2>&1');
echo "<pre>$output</pre>";
?>
<form method="post" action="unban.php">
  Unban IP<br>
  <input type="text" name="unban"><br>
  <input type="submit" value="Unban">
</form>
<form method="post" action="whitelist.php">
  Whitelist IP<br>
  <input type="text" name="whitelist"><br>
  <input type="submit" value="Whitelist">
</form>
<form method="post" action="ban.php">
  Ban IP<br>
  <input type="text" name="ban"><br>
  <input type="submit" value="Ban">
</form>
</a>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table>
<br>
</body>
</html>
