<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>Log Fail2ban Amavis - Console</title>
</head>
<body>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table>
<pre><?php
   passthru('sudo /usr/local/sbin/cbpolicyd-report');
?></pre>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table>
<br>
</body>
</html>
