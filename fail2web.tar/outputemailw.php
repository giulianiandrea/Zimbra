<?php
$outputemailw = $_POST['outputemailw'];
echo shell_exec("echo '$outputemailw' 2>&1");
echo shell_exec("sudo echo '$outputemailw' >> /opt/zimbra/conf/whitelist 2>&1");
header('Location: http://mail.pentaservice.ga:8090/amavis.php');
exit;
?>