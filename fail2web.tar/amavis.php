<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>Log Fail2ban Amavis - Console</title>
</head>
<body>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/cbpolicyd.php">Cbpolicyd</a></td>
</tr>
</tbody>
</table>
<table style="text-align: left; width: 100%;" border="0" cellpadding="0"
cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top;">
<form method="post" action="outputemailw.php">
  Whitelist mail/domain<br>
  <input type="text" name="outputemailw"><br>
  <input type="submit" value="Aggiungi">
</form>
<form method="post" action="outputemailwr.php">
  <input type="text" name="outputemailwr"><br>
  <input type="submit" value="Rimuovi">
</form>
<pre><?php
   passthru('sudo cat /opt/zimbra/conf/whitelist');
?></pre>
<a href="deloutputemailw.php?id=1">Ripristina - Azzera tutte le voci Whitelist</a><br><br>
<form method="post" action="outputemailb.php">
  Blacklist mail/domain<br>
  <input type="text" name="outputemailb"><br>
  <input type="submit" value="Aggiungi">
</form>
<form method="post" action="outputemailbr.php">
  <input type="text" name="outputemailbr"><br>
  <input type="submit" value="Rimuovi">
</form>
<pre><?php
   passthru('sudo cat /opt/zimbra/conf/blacklist');
?></pre>
<a href="deloutputemailb.php?id=1">Ripristina - Azzera tutte le voci Blacklist</a><br><br><br>
<a href="zmamavisdctlrestart.php?id=1">Applica Whitelist/Blacklist mail/domain - Riavvia servizio</a><br><br>
</td>
<td style="vertical-align: top;">
<form method="post" action="outputipw.php">
  Whitelist IP<br>
  <input type="text" name="outputipw"><br>
  <input type="submit" value="Aggiungi">
</form>
<form method="post" action="outputipwr.php">
  <input type="text" name="outputipwr"><br>
  <input type="submit" value="Rimuovi">
</form>
<pre><?php
   passthru('sudo cat /opt/zimbra/conf/postfix_rbl_override');
?></pre>
<a href="deloutputipw.php?id=1">Ripristina - Azzera tutte le voci Whitelist</a><br><br>
<form method="post" action="outputipb.php">
  Blacklist IP<br>
  <input type="text" name="outputipb"><br>
  <input type="submit" value="Aggiungi">
</form>
<form method="post" action="outputipbr.php">
  <input type="text" name="outputipbr"><br>
  <input type="submit" value="Rimuovi">
</form>
<pre><?php
   passthru('sudo cat /opt/zimbra/conf/postfix_blacklist');
?></pre>
<a href="deloutputipb.php?id=1">Ripristina - Azzera tutte le voci Blacklist</a><br><br><br>
<a href="zmmtactlrestart.php?id=1">Applica Whitelist/Blacklist IP - Riavvia servizio</a><br><br><br>
<br><br>
</td>
</tr>
</tbody>
</table>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8090/cbpolicyd.php">Cbpolicyd</a></td>
</tr>
</tbody>
</table>
</body>
</html>
