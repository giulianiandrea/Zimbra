<?php
$outputemailb = $_POST['outputemailb'];
echo shell_exec("echo '$outputemailb' 2>&1");
echo shell_exec("sudo echo '$outputemailb' >> /opt/zimbra/conf/blacklist 2>&1");
header('Location: http://mail.pentaservice.ga:8091/amavis.php');
exit;
?>