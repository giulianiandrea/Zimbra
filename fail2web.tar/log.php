<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>Log Fail2ban Amavis - Console</title>
</head>
<body>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table><br>
<span style="color: red;"></span>
<table style="text-align: left; width: 1077px; height: 228px;"
border="1" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="vertical-align: top;"><span style="color: red;">cron</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-cron.php">/var/log/cron</a></td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">fail2ban.log</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-fail2ban.php">/var/log/fail2ban.log</a></td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">maillog</span></td>
<td style="vertical-align: top; color: black;"><a
href="http://mail.pentaservice.ga:8091/log-maillog.php">/var/log/maillog</a></td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">messages</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-messages.php">/var/log/messages</a></td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">zimbra.log</span></td>
<td style="vertical-align: top; color: black;"><a
href="http://mail.pentaservice.ga:8091/log-zimbra.php">/var/log/zimbra.log</a></td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">audit.log</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-audit.php">/opt/zimbra/log/audit.log</a><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">cbpolicyd.log</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-cbpolicyd.php">/opt/zimbra/log/cbpolicyd.log</a><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">mailbox.log</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-mailbox.php">/opt/zimbra/log/mailbox.log</a><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><span style="color: red;">sync.log</span></td>
<td style="vertical-align: top;"><a
href="http://mail.pentaservice.ga:8091/log-mailbox.php">/opt/zimbra/log/sync.log</a><br>
</td>
</tr>
</tbody>
</table>
<br>
<table
style="text-align: left; height: 24px; margin-left: 300px; width: 500px;"
border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a></td>
<td style="vertical-align: top; text-align: center; width: 100px;"><a
href="http://mail.pentaservice.ga:8091/spam.php">Verifica utente SPAM</a></td>
</tr>
</tbody>
</table>
</body>
</html>
