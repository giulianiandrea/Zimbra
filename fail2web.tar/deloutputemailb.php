<?php
echo shell_exec("> /opt/zimbra/conf/blacklist 2>&1");
header('Location: http://mail.pentaservice.ga:8091/amavis.php');
exit;
?>