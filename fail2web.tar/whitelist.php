<?php
$whitelist = $_POST['whitelist'];
echo shell_exec("sudo sed -i 's%ignoreip =%& $whitelist%g' /etc/fail2ban/jail.conf 2>&1");
echo shell_exec("sudo systemctl restart fail2bban 2>&1");
header('Location: http://mail.pentaservice.ga:8091/fail2ban.php');
exit;
?>
