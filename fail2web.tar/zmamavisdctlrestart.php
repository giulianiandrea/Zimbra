<?php
echo shell_exec("sudo su - zimbra -c 'zmamavisdctl restart' 2>&1");
header('Location: http://mail.pentaservice.ga:8091/amavis.php');
exit;
?>