<html>
<head>
<meta content="text/html; charset=ISO-8859-1"
http-equiv="content-type">
<title>Log Fail2ban Amavis - Console</title>
</head>
<body>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a>&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a>&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a>&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a><br>
&nbsp;&nbsp;&nbsp; <br>
<pre><?php
   passthru('sudo cat /opt/zimbra/log/cbpolicyd.log');
?></pre>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://mail.pentaservice.ga:8091/log.php" target="_top">Log</a>&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/fail2ban.php">Fail2ban</a>&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/amavis.php">Amavis</a>&nbsp;&nbsp;
&nbsp;&nbsp; &nbsp;&nbsp; <a
href="http://mail.pentaservice.ga:8091/cbpolicyd.php">Cbpolicyd</a><br>
&nbsp;&nbsp;&nbsp; <br>
</body>
</html>
