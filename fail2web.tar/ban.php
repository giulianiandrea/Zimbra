<?php
$ban = $_POST['ban'];
echo shell_exec("sudo fail2ban-client set zimbra banip $ban 2>&1");
echo shell_exec("sudo systemctl restart fail2bban 2>&1");
header('Location: http://mail.pentaservice.ga:8091/fail2ban.php');
exit;
?>
