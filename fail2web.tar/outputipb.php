<?php
$outputipb = $_POST['outputipb'];
echo shell_exec("sudo echo '$outputipb REJECT' >> /opt/zimbra/conf/postfix_blacklist 2>&1");
echo shell_exec("su - zimbra -c 'postmap /opt/zimbra/conf/postfix_blacklist' 2>&1");
header('Location: http://mail.pentaservice.ga:8091/amavis.php');
exit;
?>