<?php
$outputipbr = $_POST['outputipbr'];
    $filename = '/opt/zimbra/conf/postfix_blacklist';
    $lines = file($filename); // reads a file into a array with the lines
    $output = '';

    foreach ($lines as $line) {
        if (!strstr($line, $outputipbr)) {
            $output .= $line;
        } 
    }

    // replace the contents of the file with the output
    file_put_contents($filename, $output);
header('Location: http://mail.pentaservice.ga:8090/amavis.php');
exit;
?>