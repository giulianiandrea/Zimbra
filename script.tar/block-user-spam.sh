#!/bin/bash
DOMAIN=$(hostname -d)
cur_month=`date +%b`
cur_month="${cur_month^}"
cur_day=`date +%e|sed 's/ //g'`
cur_hours=`date +%k`
let cur_hours2=$cur_hours-1
NUMEROIP=3

IFS=$'
'
rm -rf /tmp/sasl_tmp_users
for WORD in `cat /var/log/maillog|grep "sasl_username"|sed 's/ //g'|grep -e ^$cur_month$cur_day$cur_hours -e ^$cur_month$cur_day$cur_hours2`
do
  user=`echo $WORD|awk -F"sasl_username=" '{print $2}'|sed 's/@$DOMAIN//g'`
  ip=`echo $WORD|awk -F"[" '{print $3}'|awk -F"]" '{print $1}'`
  echo $user $ip >> /tmp/sasl_tmp_users
done

for WORD in `cat /tmp/sasl_tmp_users | sort |uniq|awk '{print $1}'|sort|uniq -c`
do
s=`echo $WORD | awk -F" " '{print $1}'`
w=`echo $WORD | awk -F" " '{print $2}'`
if [ $((s)) -ge $NUMEROIP ]
then
  echo ""$w": Login bloccato per accessi da $NUMEROIP IP diversi in 1 ora"
  su - zimbra -c "/opt/zimbra/bin/zmprov ma $w zimbraAccountStatus locked"
  su - zimbra -c "postlog Utente $w bloccato, login avvenuto da $NUMEROIP IP diversi"
  echo "From: admin@$DOMAIN" > /opt/zimbra/message_s
  echo "To: services@$DOMAIN" >> /opt/zimbra/message_s
  echo "Subject: Utente $w bloccato per probabile SPAM" >> /opt/zimbra/message_s
  echo "Utente $w bloccato per probabile SPAM, login avvenuto da $NUMEROIP IP diversi in 1 ora" >> /opt/zimbra/message_s
  su - zimbra -c "/opt/zimbra/common/sbin/sendmail services@$DOMAIN < /opt/zimbra/message_s"
  rm -rf /opt/zimbra/message_s
fi

done
