#!/bin/sh
LIMITEMAIL=7
#PATH=/usr/local/bin:/bin:/usr/bin
#export PATH

perl <<'EOF'> temp.txt
#!/usr/bin/perl
#
# usage: totalEmail.pl
# summary: count the number of recipients that each accounts has sent email to
#
%sender_list = ();  #ip list
chdir "/var/log";
for (glob 'zimbra.log*')
#for (glob 'zimbra.log')
{
  # audit.log is always todays stuff
  #print "***** Opening file $_","\n";
  if ($_ eq 'zimbra.log')
  {
     $audit_log = 1;
     open (IN, sprintf("cat %s |", $_))
       or die("Can't open pipe from command 'zcat $filename' : $!\n");
  }
  else
  {
     $audit_log = 0;
     open (IN, sprintf("zcat %s |", $_))
       or die("Can't open pipe from command 'zcat $filename' : $!\n");
  }
  while (<IN>)
  {
   if (m#RelayedOutbound#)
   {
      my $recipcnt = 0;
      next if (m#dkim_s#);   # messasges are listed twice (first via clamav then dkim signed)
      ($sender, $recipients) = m#[^<]+<([^>]+)>[^<]+(.*)\s+Queue-ID#;
                $recipcnt = $recipients =~ tr/,/,/;
      $sender_list{$sender} += $recipcnt;   # count number or recipients
      #print "sender $sender, recipients $recipients count: $sender_list{$sender}\n";
   }
   }
close (IN);
}
# print out totals per sender
printSenders();
sub printSenders
{
   my $sender = ();
   for $sender (sort {$sender_list{$b} <=> $sender_list{$a}} keys %sender_list)
   {
      print "$sender $sender_list{$sender}\n";
   }
}
EOF
DOMAIN=$(hostname -d)
cat temp.txt | grep -v "^\(admin@\|wiki@\|spam.*@\|ham.*@\|galsync.*@\|virus.*@\)" > emailsent.txt
rm  -rf temp.txt
while IFS=' ' read -r account emailsent
do
  if (( $emailsent > $LIMITEMAIL )); then
     su - zimbra -c "/opt/zimbra/bin/zmprov ma $account zimbraAccountStatus locked"
     #echo ""$account": Login bloccato per probabile SPAM. Inviate $emailsent mail"
     su - zimbra -c "postlog Utente $account bloccato, inviate $emailsent mail"
     echo "From: admin@$DOMAIN" > /tmp/message_s
     echo "To: services@$DOMAIN" >> /tmp/message_s
     echo "Subject: Utente $account bloccato per probabile SPAM" >> /tmp/message_s
     echo "Utente $account bloccato per probabile SPAM, inviate $emailsent mail. Il limite imposto era $LIMITEMAIL" >> /tmp/message_s
     su - zimbra -c "/opt/zimbra/common/sbin/sendmail services@$DOMAIN < /tmp/message_s"
     rm -rf /tmp/message_s
  fi
done < emailsent.txt
rm  -rf emailsent.txt
