#!/bin/sh
centosmajorrelease=$(cat /etc/centos-release | tr -dc '0-9.'|cut -d \. -f1)
# Cancellazione certbot_zimbra.sh
cd /usr/local/bin/
rm -f certbot_zimbra.sh
cd /home
mkdir script
cd script
# Download certbot_zimbra.sh
if [ "$centosmajorrelease" = "7" ]
then
rm -rf certbot-zimbra-0*
rm -rf certbot-zimbra-0.7.11.tar.gz
wget --content-disposition https://github.com/YetOpen/certbot-zimbra/archive/0.7.11.tar.gz
tar xzf certbot-zimbra-0.7.11.tar.gz
cd certbot-zimbra-0.7.11
chmod +x certbot_zimbra.sh
chown root: certbot_zimbra.sh
mv certbot_zimbra.sh /usr/local/bin/
fi
if [ "$centosmajorrelease" = "8" ]
then
rm -rf /master.zip
rm -rf /root/certbot-zimbra-master
wget -P ~/ https://github.com/YetOpen/certbot-zimbra/archive/master.zip
unzip ~/master.zip
rm -rf /master.zip
cd /root/certbot-zimbra-master
mv certbot_zimbra.sh /usr/local/bin/
rm -rf /root/certbot-zimbra-master
chmod +x certbot_zimbra.sh
chown root: certbot_zimbra.sh
mv certbot_zimbra.sh /usr/local/bin/
fi
# Disabilitazione TLS-SSL
su - zimbra -c "zmlocalconfig -e ldap_starttls_required=false"
su - zimbra -c "zmlocalconfig -e ldap_starttls_supported=0"
su - zimbra -c "zmcontrol restart"
# Permessi 777 a /root
chmod 777 /root
# Installazione certificato SSL generico
su - zimbra -c "/opt/zimbra/bin/zmcertmgr createca -new"
su - zimbra -c "/opt/zimbra/bin/zmcertmgr deployca"
su - zimbra -c "/opt/zimbra/bin/zmcertmgr createcrt -new -days 365"
su - zimbra -c "/opt/zimbra/bin/zmcertmgr deploycrt self"
# Riabilitazione TLS-SSL con certificato generico
su - zimbra -c "zmlocalconfig -e ldap_starttls_required=true"
su - zimbra -c "zmlocalconfig -e ldap_starttls_supported=1"
su - zimbra -c "zmcontrol restart"
# Installazione nuove certificato Let’s Encrypt
cd /usr/local/bin/
(
echo y                        #Is this correct?
echo y                        #We will now run certbot to request the certificate. Proceed?
echo 2                        #2: Renew & replace the cert (may be subject to CA rate limits)
echo y                        #Deploy certificates to Zimbra? This may restart some services.
echo y                        #Restart Zimbra? y
) | ./certbot_zimbra.sh -n -c
# Ripristino permessi /root
